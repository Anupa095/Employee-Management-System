package com.emphr.emphr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmphrApplicationTests {

	@Test
	void contextLoads() {
	}

}
